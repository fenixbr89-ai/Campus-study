// Typed fetch layer over the FastAPI backend. Base is the relative "/api" prefix so the
// same code works in dev (Vite proxies /api → :8001) and behind a single origin in prod.
const BASE = (import.meta.env.VITE_API_URL || "/api").replace(/\/$/, "");

// Fields are declared, not constructor parameter properties: tsconfig sets
// erasableSyntaxOnly, which rejects `constructor(readonly status: number)`.
export class ApiError extends Error {
  status: number;
  body: unknown;

  constructor(status: number, body: unknown) {
    super(`request failed with ${status}`);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
  }
}

type JsonBody = unknown;

// Algumas respostas antigas armazenaram quebras de linha escapadas como texto literal.
// Normaliza strings recursivamente antes que qualquer tela as apresente.
function normalizeResponse<T>(value: T): T {
  if (typeof value === "string") {
    return value.replace(/\\r\\n/g, "\n").replace(/\\n/g, "\n").replace(/\\r/g, "\n") as unknown as T;
  }
  if (Array.isArray(value)) return value.map((item) => normalizeResponse(item)) as unknown as T;
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, item]) => [key, normalizeResponse(item)])) as unknown as T;
  }
  return value;
}

async function request<T>(method: string, path: string, body?: JsonBody, signal?: AbortSignal): Promise<T> {
  // Auth rides the httpOnly session cookie automatically — never add auth headers here.
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  });

  // FastAPI reports request-validation failures as 422 with a {detail: [...]} body.
  if (!res.ok) {
    const errBody = normalizeResponse(await res.json().catch(() => null));
    throw new ApiError(res.status, errBody);
  }

  if (res.status === 204) return undefined as T;
  return normalizeResponse(await res.json()) as T;
}

// The response type is yours to declare: nothing infers across the Python boundary, so a
// TS interface here mirrors the endpoint's Pydantic model by hand — keep the two in sync.
export const apiGet = <T>(path: string) => request<T>("GET", path);
export const apiPost = <T>(path: string, body?: JsonBody) => request<T>("POST", path, body ?? null);
export const apiPut = <T>(path: string, body?: JsonBody) => request<T>("PUT", path, body ?? null);
export const apiPatch = <T>(path: string, body?: JsonBody) =>
  request<T>("PATCH", path, body ?? null);
export const apiDelete = <T>(path: string) => request<T>("DELETE", path);
export const apiPostSignal = <T>(path: string, body: JsonBody, signal?: AbortSignal) => request<T>("POST", path, body, signal);


export function apiAssetUrl(path: string | undefined | null): string {
  if (!path) return "";
  if (/^(https?:|data:|blob:)/i.test(path)) return path;
  const base = BASE;
  if (/^https?:\/\//i.test(base)) return `${base}${path.startsWith("/") ? path : `/${path}`}`;
  return path;
}

export const apiUpload = async <T>(path: string, formData: FormData, signal?: AbortSignal): Promise<T> => {
  const res = await fetch(`${BASE}${path}`, { method: "POST", body: formData, signal });
  if (!res.ok) {
    const errBody = normalizeResponse(await res.json().catch(() => null));
    throw new ApiError(res.status, errBody);
  }
  return normalizeResponse(await res.json()) as T;
};
