import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRight, BarChart3, CalendarDays, Check, CheckCircle2, Clock, Flame, GraduationCap, HelpCircle, Loader2, NotebookPen, Play, Plus, Search, Square, Target, Trash2, Trophy, Edit3 } from "lucide-react";
import { apiDelete, apiGet, apiPost, apiPut } from "@/lib/api";
import { toast } from "sonner";
import { errMsg, useMe, usePageMeta } from "@/lib/hooks";
import { minutesLabel } from "@/lib/format";
import type { AcademicDashboard, Discipline, ExamPlan, ExamTask, HomeOut, StudySession, SmartSearchResult } from "@/lib/types";
import { Row } from "@/components/ContentCard";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function SearchHero({ initial = "", autoFocus = false }: { initial?: string; autoFocus?: boolean }) {
  const [q, setQ] = useState(initial);
  const nav = useNavigate();
  const search = useMutation({
    mutationFn: () => apiGet<SmartSearchResult>(`/smart-search?q=${encodeURIComponent(q.trim())}`),
    onSuccess: (result) => nav(result.type === "search" ? `/pesquisa?q=${encodeURIComponent(q.trim())}` : result.path),
    onError: () => nav(`/pesquisa?q=${encodeURIComponent(q.trim())}`),
  });
  return (
    <form data-testid="global-search-form" onSubmit={(e) => { e.preventDefault(); if (q.trim()) search.mutate(); }}
      className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-lg shadow-emerald-900/5 transition-shadow duration-200 focus-within:shadow-xl focus-within:ring-2 focus-within:ring-brand/30">
      <Search className="ml-3 size-5 shrink-0 text-slate-400" />
      <input data-testid="global-search-input" autoFocus={autoFocus} value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Pesquise: inflamação, nervo trigêmeo, derivadas…"
        className="h-12 min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-slate-400 sm:text-lg" />
      <button data-testid="global-search-submit" type="submit"
        className="h-12 rounded-xl bg-brand px-5 font-semibold text-white transition-[background-color,transform] duration-150 hover:bg-brand-dark active:scale-[0.97]">
        {search.isPending ? "Encontrando…" : "Pesquisar"}
      </button>
    </form>
  );
}

const TOOLS = [
  { to: "/ranking", icon: Trophy, label: "Ranking", desc: "Acompanhe sua pontuação mensal", featured: true },
  { to: "/simulados", icon: HelpCircle, label: "Simulados", desc: "Treine com nota e explicações" },
  { to: "/biblioteca", icon: NotebookPen, label: "Salvos", desc: "Acesse seus materiais e resumos", wide: true },
  { to: "/anotacoes", icon: NotebookPen, label: "Anotações", desc: "Guarde observações pessoais de qualquer conteúdo" },
  { to: "/meu-plano", icon: CalendarDays, label: "Meu plano de estudos", desc: "Organize sua rotina" },
  { to: "/progresso", icon: Target, label: "Progresso", desc: "Acompanhe metas e sua evolução" },
];

function UpcomingExamCard({ plan, onAdd, onEdit }: { plan?: ExamPlan | null; onAdd: () => void; onEdit: () => void }) {
  const qc = useQueryClient();
  const [activeSession, setActiveSession] = useState<StudySession | null>(null);
  const [now, setNow] = useState(Date.now());
  const remove = useMutation({
    mutationFn: async () => {
      if (!plan?.id) throw new Error("ID da prova não encontrado.");
      await qc.cancelQueries({ queryKey: ["home"] });
      return apiDelete<{ message: string }>(`/exam-plans/${plan.id}`);
    },
    onMutate: async () => {
      const previous = qc.getQueryData<HomeOut>(["home"]);
      qc.setQueryData<HomeOut>(["home"], (current) => current ? { ...current, upcoming_exam: null } : current);
      return { previous };
    },
    onSuccess: async () => {
      toast.success("Prova excluída.");
      await qc.invalidateQueries({ queryKey: ["home"] });
      await qc.invalidateQueries({ queryKey: ["study-plan"] });
    },
    onError: (e, _vars, context) => {
      if (context?.previous) qc.setQueryData(["home"], context.previous);
      toast.error(errMsg(e));
    },
  });
  const tasks = useQuery({ queryKey: ["exam-tasks", plan?.id], queryFn: () => apiGet<ExamTask[]>(`/exam-plans/${plan!.id}/tasks`), enabled: !!plan });
  const start = useMutation({ mutationFn: (taskId: string) => apiPost<StudySession>("/study-sessions", { task_id: taskId }), onSuccess: (session) => { setActiveSession(session); setNow(Date.now()); } });
  const stop = useMutation({ mutationFn: () => apiPost<StudySession>(`/study-sessions/${activeSession!.id}/stop`), onSuccess: () => { setActiveSession(null); qc.invalidateQueries({ queryKey: ["home"] }); qc.invalidateQueries({ queryKey: ["progress"] }); } });
  const complete = useMutation({ mutationFn: (taskId: string) => apiPost<{ message: string }>(`/exam-tasks/${taskId}/complete`), onSuccess: () => { qc.invalidateQueries({ queryKey: ["home"] }); qc.invalidateQueries({ queryKey: ["exam-tasks", plan?.id] }); qc.invalidateQueries({ queryKey: ["progress"] }); } });

  useEffect(() => {
    if (!activeSession) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    const onVisibility = () => { if (document.visibilityState === "hidden" && !stop.isPending) stop.mutate(); };
    document.addEventListener("visibilitychange", onVisibility);
    return () => { window.clearInterval(id); document.removeEventListener("visibilitychange", onVisibility); };
  }, [activeSession]);

  useEffect(() => {
    if (!activeSession || !tasks.data) return;
    const task = tasks.data.find((t) => t.id === activeSession.task_id);
    if (!task) return;
    const elapsed = Math.max(0, Math.floor((now - new Date(activeSession.started_at).getTime()) / 1000));
    if (elapsed >= task.minutes * 60 && !stop.isPending) {
      stop.mutate();
      complete.mutate(task.id);
    }
  }, [activeSession, now, tasks.data]);

  if (!plan) return (
    <section className="mt-8 rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-white p-5 sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div><p className="text-sm font-semibold text-brand-dark">📆 Prova chegando?</p><h2 className="mt-1 text-xl font-bold">Organize seus estudos antes da prova</h2><p className="mt-1 text-sm text-slate-600">Cadastre uma prova e o Campus Study calcula o que você precisa estudar.</p></div>
        <button type="button" onClick={onAdd} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brand px-5 font-semibold text-white hover:bg-brand-dark"><Plus className="size-4" /> Cadastrar prova</button>
      </div>
    </section>
  );

  const today = new Date().toISOString().slice(0, 10);
  const todayTasks = (tasks.data ?? []).filter((t) => t.task_date === today);
  const activeTask = activeSession ? todayTasks.find((t) => t.id === activeSession.task_id) : null;
  const activeSeconds = activeSession ? Math.max(0, Math.floor((now - new Date(activeSession.started_at).getTime()) / 1000)) : 0;
  const activeMinutes = Math.floor(activeSeconds / 60).toString().padStart(2, "0");
  const activeRestSeconds = (activeSeconds % 60).toString().padStart(2, "0");

  return (
    <section data-testid="home-upcoming-exam" className="mt-8 rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-50 via-white to-white p-5 shadow-sm sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-sm font-semibold text-brand-dark">📆 Prova chegando</p><h2 className="mt-1 text-2xl font-extrabold tracking-tight">{plan.title}</h2><p className="mt-1 flex items-center gap-1.5 text-sm text-slate-600"><CalendarDays className="size-4" /> {new Date(`${plan.exam_date}T12:00:00`).toLocaleDateString("pt-BR")}</p></div><div className="flex gap-1"><button type="button" aria-label="Editar prova" onClick={onEdit} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-brand-dark"><Edit3 className="size-4" /></button><button type="button" aria-label="Excluir plano da prova" onClick={() => window.confirm("Excluir esta prova e as tarefas relacionadas?") && remove.mutate()} disabled={remove.isPending} className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"><Trash2 className="size-4" /></button></div></div>
      <div className="mt-5 grid gap-4 sm:grid-cols-[1fr_auto]"><div><p className="text-3xl font-extrabold text-brand-dark">Faltam {plan.days_left} {plan.days_left === 1 ? "dia" : "dias"}.</p><div className="mt-3 flex items-center justify-between text-sm"><span className="font-semibold">Seu progresso: {plan.progress_pct}%</span><span className="text-slate-500">{plan.topics_completed}/{plan.topics_total} assuntos</span></div><div className="mt-2 h-2.5 overflow-hidden rounded-full bg-emerald-100"><div className="h-full rounded-full bg-brand" style={{ width: `${plan.progress_pct}%` }} /></div></div><div className="grid grid-cols-3 gap-2 sm:min-w-72"><div className="rounded-2xl bg-white p-3 text-center shadow-sm"><p className="text-xl font-bold text-emerald-600">{plan.topics_completed}</p><p className="text-[11px] text-slate-500">Concluídos</p></div><div className="rounded-2xl bg-white p-3 text-center shadow-sm"><p className="text-xl font-bold text-amber-500">{plan.topics_in_progress}</p><p className="text-[11px] text-slate-500">Em andamento</p></div><div className="rounded-2xl bg-white p-3 text-center shadow-sm"><p className="text-xl font-bold text-red-500">{plan.topics_pending}</p><p className="text-[11px] text-slate-500">Pendentes</p></div></div></div>
      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">{[["📝", String(plan.questions_to_practice), "questões"],["🔄", String(plan.revisions), "revisões"],["🎯", String(plan.mock_exams), "simulados"],["⏱️", `${plan.daily_minutes} min`, "por dia"]].map(([icon, value, label]) => <div key={label} className="rounded-2xl border border-slate-100 bg-white p-3"><span>{icon}</span><p className="mt-1 font-bold">{value}</p><p className="text-xs text-slate-500">{label}</p></div>)}</div>

      <div className="mt-5 rounded-2xl border border-emerald-100 bg-white p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-bold uppercase tracking-wide text-brand-dark">Plano de hoje</p><p className="mt-1 font-semibold">Tarefas salvas para {new Date(`${today}T12:00:00`).toLocaleDateString("pt-BR", { day: "2-digit", month: "long" })}</p></div>{activeSession && <div className="rounded-xl bg-emerald-50 px-3 py-2 text-lg font-extrabold text-brand-dark tabular-nums">{activeMinutes}:{activeRestSeconds}</div>}</div>
        <div className="mt-4 space-y-2">
          {tasks.isLoading && <p className="text-sm text-slate-500">Montando seu plano diário...</p>}
          {!tasks.isLoading && todayTasks.length === 0 && <p className="text-sm text-slate-500">Nenhuma tarefa pendente hoje. O plano será recalculado conforme seu progresso.</p>}
          {todayTasks.map((task) => {
            const running = activeSession?.task_id === task.id;
            return <div key={task.id} className={`flex flex-col gap-3 rounded-2xl border p-3 sm:flex-row sm:items-center sm:justify-between ${task.completed ? "border-emerald-100 bg-emerald-50/60" : "border-slate-100 bg-slate-50/60"}`}>
              <div className="flex min-w-0 items-start gap-3"><span className={`mt-0.5 grid size-9 shrink-0 place-items-center rounded-xl ${task.completed ? "bg-emerald-100 text-emerald-700" : "bg-white text-brand"}`}>{task.completed ? <Check className="size-4" /> : task.kind === "topic" ? <GraduationCap className="size-4" /> : task.kind === "questions" ? <HelpCircle className="size-4" /> : <CheckCircle2 className="size-4" />}</span><div className="min-w-0"><p className={`font-semibold ${task.completed ? "text-emerald-800 line-through" : ""}`}>{task.title}</p><p className="text-xs text-slate-500">{task.minutes} minutos{task.topic_name ? ` · ${task.topic_name}` : ""}</p></div></div>
              {!task.completed && <div className="flex shrink-0 gap-2"><button type="button" onClick={() => running ? stop.mutate() : start.mutate(task.id)} disabled={start.isPending || stop.isPending || (!!activeSession && !running)} className="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-brand px-4 text-sm font-semibold text-white disabled:opacity-50">{(start.isPending || stop.isPending) && running ? <Loader2 className="size-4 animate-spin" /> : running ? <Square className="size-3.5" /> : <Play className="size-4" />}{running ? "Parar" : "Começar"}</button><button type="button" onClick={() => complete.mutate(task.id)} disabled={complete.isPending || !!activeSession} className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-700 disabled:opacity-50">Concluir</button></div>}
            </div>;
          })}
        </div>
        {activeTask && <p className="mt-3 text-xs text-slate-500">A sessão registra o tempo real estudado. Ao atingir {activeTask.minutes} minutos, a tarefa é concluída e o plano é recalculado automaticamente.</p>}
      </div>
    </section>
  );
}

function ExamPlanDialog({ open, onOpenChange, courseId, plan }: { open: boolean; onOpenChange: (v: boolean) => void; courseId?: string | null; plan?: ExamPlan | null }) {
  const qc = useQueryClient(); const [title, setTitle] = useState("Prova de Matemática"); const [examDate, setExamDate] = useState(""); const [disciplineId, setDisciplineId] = useState("");
  const disciplines = useQuery({ queryKey: ["exam-plan-disciplines", courseId], queryFn: () => apiGet<Discipline[]>(`/filters/disciplines${courseId ? `?course_id=${encodeURIComponent(courseId)}` : ""}`), enabled: open });
  useEffect(() => { if (!open) return; setTitle(plan?.title ?? "Prova de Matemática"); setExamDate(plan?.exam_date ?? ""); setDisciplineId(plan?.discipline_id ?? ""); }, [open, plan]);
  const save = useMutation({ mutationFn: () => plan ? apiPut<ExamPlan>(`/exam-plans/${plan.id}`, { title: title.trim(), exam_date: examDate, discipline_id: disciplineId }) : apiPost<ExamPlan>("/exam-plans", { title: title.trim(), exam_date: examDate, discipline_id: disciplineId }), onSuccess: () => { toast.success(plan ? "Prova atualizada." : "Prova cadastrada e plano calculado."); qc.invalidateQueries({ queryKey: ["home"] }); qc.invalidateQueries({ queryKey: ["study-plan"] }); onOpenChange(false); }, onError: e => toast.error(errMsg(e)) });
  const today = new Date().toISOString().slice(0, 10);
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="max-w-lg rounded-3xl p-6"><DialogHeader><DialogTitle className="text-xl">📆 {plan ? "Editar prova" : "Cadastrar prova"}</DialogTitle></DialogHeader><form className="space-y-4" onSubmit={(e) => { e.preventDefault(); if (title.trim() && examDate && disciplineId) save.mutate(); }}><div><label className="text-sm font-medium">Nome da prova</label><input required value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-brand" placeholder="Prova de Matemática" /></div><div className="grid gap-3 sm:grid-cols-2"><div><label className="text-sm font-medium">Data da prova</label><input required min={today} type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-brand" /></div><div><label className="text-sm font-medium">Disciplina</label><select required value={disciplineId} onChange={(e) => setDisciplineId(e.target.value)} className="mt-1 h-11 w-full rounded-xl border border-slate-200 bg-white px-3 outline-none focus:border-brand"><option value="">Selecione...</option>{disciplines.data?.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div></div>{save.isError && <p className="text-sm text-red-600">Não foi possível salvar a prova. Confira os campos e tente novamente.</p>}<button disabled={save.isPending || !examDate || !disciplineId} className="h-11 w-full rounded-xl bg-brand font-semibold text-white disabled:opacity-50">{save.isPending ? "Salvando e calculando plano..." : plan ? "Salvar alterações" : "Cadastrar e calcular plano"}</button></form></DialogContent></Dialog>;
}

export default function Home() {
  usePageMeta("Início");
  const me = useMe();
  const home = useQuery({ queryKey: ["home"], queryFn: () => apiGet<HomeOut>("/home") });
  const site = useQuery({ queryKey: ["site-config-public"], queryFn: () => apiGet<any>("/site-config/public") });
  const academic = useQuery({ queryKey: ["academic-dashboard"], queryFn: () => apiGet<AcademicDashboard>("/academic-dashboard") });
  const data = home.isError ? undefined : home.data;
  const first = me.data?.name.split(" ")[0] ?? "";
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
  const p = data?.progress;
  const goalPct = p ? Math.min(100, Math.round((p.minutes_today / Math.max(1, p.daily_goal_minutes)) * 100)) : 0;
  const [examDialogOpen, setExamDialogOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<ExamPlan | null>(null);

  return (
    <div className="animate-fade-up">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-100 via-green-50 to-white p-6 sm:p-10">
        <div className="pointer-events-none absolute -top-20 -right-20 size-72 rounded-full bg-emerald-200/50 blur-3xl" />
        <p className="relative text-sm font-semibold text-brand-dark">{greet}{first && `, ${first}`} 👋</p>
        <h1 data-testid="home-greeting" className="relative mt-1 max-w-2xl text-3xl leading-[1.15] font-extrabold tracking-tight text-slate-900 sm:text-4xl">
          {site.data?.home_texts?.["home.title"] || "O que vamos estudar hoje?"}
        </h1>
        <div className="relative mt-6 max-w-3xl"><SearchHero /></div>
      </section>

      <section data-testid="home-progress" className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { icon: Flame, label: "Sequência", value: `${p?.streak_days ?? 0} dias` },
          { icon: Clock, label: "Hoje", value: minutesLabel(p?.minutes_today ?? 0) },
          { icon: Target, label: "Pontos", value: String(p?.points ?? 0) },
          { icon: GraduationCap, label: "Assuntos concluídos", value: String(p?.topics_completed ?? 0) },
        ].map((s) => (
          <Link to="/progresso" key={s.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition-transform duration-200 hover:-translate-y-0.5">
            <s.icon className="size-5 text-brand" />
            <p className="mt-2 font-heading text-xl font-bold">{s.value}</p>
            <p className="text-xs text-slate-500">{s.label}</p>
          </Link>
        ))}
      </section>
      <div className="mt-3 rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex justify-between text-sm"><span className="font-medium">Meta diária</span><span className="text-slate-500">{p?.minutes_today ?? 0}/{p?.daily_goal_minutes ?? 60} min</span></div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-brand transition-[width] duration-500" style={{ width: `${goalPct}%` }} /></div>
      </div>

      {academic.data && (
        <section className="mt-8 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6" data-testid="academic-dashboard">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div><p className="text-xs font-bold uppercase tracking-[0.16em] text-brand-dark">Visão acadêmica</p><h2 className="mt-1 text-2xl font-extrabold">{academic.data.course_name || "Seu percurso acadêmico"}</h2><p className="mt-1 text-sm text-slate-500">{academic.data.period_name ? `${academic.data.period_name} · ` : ""}{academic.data.topics_completed}/{academic.data.topics_total} assuntos concluídos</p></div>
            <Link to="/progresso" className="inline-flex items-center gap-2 text-sm font-semibold text-brand-dark">Ver desempenho <BarChart3 className="size-4" /></Link>
          </div>
          <div className="mt-5 h-3 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-brand transition-[width] duration-500" style={{width:`${Math.min(100, academic.data.progress_pct)}%`}} /></div>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[['Questões', academic.data.questions_answered],['Acerto', `${academic.data.correct_rate}%`],['Simulados', academic.data.exams_taken],['Estudo', `${academic.data.minutes_total} min`]].map(([label,value])=><div key={String(label)} className="rounded-2xl bg-slate-50 p-3"><p className="text-lg font-bold">{value}</p><p className="text-xs text-slate-500">{label}</p></div>)}
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {academic.data.recommendations.slice(0,4).map(r=><Link key={r.id} to={r.path} className="rounded-2xl border border-emerald-100 bg-emerald-50/60 p-4 transition-colors hover:border-brand/40"><p className="font-semibold">{r.title}</p><p className="mt-1 text-xs text-slate-600">Por quê: {r.reason}</p></Link>)}
          </div>
        </section>
      )}

      <UpcomingExamCard plan={data?.upcoming_exam} onAdd={() => { setEditingExam(null); setExamDialogOpen(true); }} onEdit={() => { setEditingExam(data?.upcoming_exam ?? null); setExamDialogOpen(true); }} />
      <ExamPlanDialog open={examDialogOpen} onOpenChange={(v) => { setExamDialogOpen(v); if (!v) setEditingExam(null); }} courseId={me.data?.course_id} plan={editingExam} />

      {data && data.continue_studying.length > 0 && (
        <section data-testid="home-continue-studying" className="mt-10">
          <h2 className="mb-4 text-xl font-bold tracking-tight">Continuar estudando</h2>
          <div className="no-scrollbar -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2">
            {data.continue_studying.map((h) => (
              <Link key={h.topic_id} to={h.path} data-testid={`continue-item-${h.topic_id}`}
                className="w-60 shrink-0 snap-start rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-md">
                <p className="text-xs text-slate-500">{h.course_name}</p>
                <p className="mt-1 font-semibold">{h.topic_name}</p>
                <p className="text-sm text-slate-500">{h.discipline_name}</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="mt-10" data-testid="home-study-tools">
        <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-xl font-bold tracking-tight">Ferramentas de estudo</h2>
            <p className="mt-1 max-w-2xl text-sm text-slate-500">Tudo o que você já usa para organizar, praticar e acompanhar seus estudos em um só lugar.</p>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {TOOLS.map((t) => (
            <Link
              key={t.to}
              to={t.to}
              data-testid={`home-tool-${t.to.slice(1)}`}
              className={
                t.featured
                  ? "group min-h-44 rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-50 via-white to-white p-5 shadow-sm transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-lg sm:col-span-2 lg:row-span-2"
                  : t.wide
                    ? "group min-h-36 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-md lg:col-span-2"
                    : "group min-h-36 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-md"
              }
            >
              <span className={`grid size-11 place-items-center rounded-xl ${t.featured ? "bg-brand text-white" : "bg-brand-soft text-brand-dark"} transition-colors group-hover:bg-brand group-hover:text-white`}>
                <t.icon className="size-5" />
              </span>
              <div className="mt-4 flex items-start justify-between gap-3">
                <div>
                  <p className={t.featured ? "text-lg font-extrabold tracking-tight" : "font-bold"}>{t.label}</p>
                  <p className="mt-1 max-w-sm text-sm leading-5 text-slate-500">{t.desc}</p>
                </div>
                <ArrowRight className="mt-0.5 size-4 shrink-0 text-slate-300 transition-transform duration-200 group-hover:translate-x-1 group-hover:text-brand" />
              </div>
              {t.featured && <p className="mt-5 text-xs font-semibold text-brand-dark">Veja sua posição e sua evolução no ranking mensal.</p>}
            </Link>
          ))}
        </div>
      </section>

      {site.data?.sections?.courses !== false && <section data-testid="home-courses" className="mt-10">
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-xl font-bold tracking-tight">Cursos</h2>
          <Link to="/cursos" data-testid="home-all-courses-link" className="text-sm font-semibold text-brand-dark">Ver todos</Link>
        </div>
        <div className="no-scrollbar -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2">
          {(data?.courses ?? []).map((c) => (
            <Link key={c.id} to={`/cursos/${c.slug}`} data-testid={`home-course-${c.slug}`}
              className="w-44 shrink-0 snap-start rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-md">
              <GraduationCap className="size-6 text-brand" />
              <p className="mt-3 font-semibold leading-tight">{c.name}</p>
              <p className="text-xs text-slate-500">{c.num_periods} períodos</p>
            </Link>
          ))}
        </div>
      </section>}

      {site.data?.sections?.recommended !== false && <Row title={site.data?.home_texts?.["home.recommended"] || "Recomendados para você"} items={data?.recommended ?? []} testId="home-recommended" empty="Assim que houver materiais publicados, eles aparecem aqui." />}
      {site.data?.sections?.videos !== false && <Row title={site.data?.home_texts?.["home.videos"] || "Videoaulas"} items={data?.videos ?? []} testId="home-videos" empty="Nenhuma videoaula publicada ainda. Os administradores estão curando videoaulas reais do YouTube." />}
      {site.data?.sections?.articles !== false && <Row title={site.data?.home_texts?.["home.articles"] || "Artigos científicos"} items={data?.articles ?? []} testId="home-articles" empty="Nenhum artigo científico publicado ainda. Em breve, artigos com fontes verificadas." />}
    </div>
  );
}
